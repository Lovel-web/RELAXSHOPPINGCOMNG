
  # Figma Workflow for RelaxShopping

  This is a code bundle for Figma Workflow for RelaxShopping. The original project is available at https://www.figma.com/design/45euB2FnX44L9Uv5BMQMpN/Figma-Workflow-for-RelaxShopping.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  