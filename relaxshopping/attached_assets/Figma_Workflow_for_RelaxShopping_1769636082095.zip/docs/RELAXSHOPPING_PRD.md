# RelaxShopping - Product Requirements Document

**Last Updated:** January 3, 2026  
**Status:** Source of Truth (Final)

---

## 🎯 Core Product Vision

RelaxShopping is a Nigerian grocery & essentials platform built around:

- **Calm shopping** (no urgency pressure)
- **Batch-based delivery** (predictable timing)
- **Territory-based micro-fulfillment zones** (assignment groups)
- **Predictability** over urgency

**This is NOT an on-demand app.**

---

## 👥 User Roles (FINAL & IMMUTABLE)

There are **ONLY five roles** in the system:

| Role        | Public Signup | Approval Needed | Purpose                    |
|-------------|---------------|-----------------|----------------------------|
| Customer    | ✅ Yes        | ❌ No           | Buy groceries              |
| Vendor      | ✅ Yes        | ✅ Yes          | Sell products              |
| Staff       | ✅ Yes        | ✅ Yes          | Deliver orders             |
| Admin       | ❌ No         | Internal only   | State-level operations     |
| Superadmin  | ❌ No         | In-built only   | Global operations control  |

### Critical Rules:
- 🚫 **No Admin signup** - Admins are upgraded from Staff by Superadmin
- 🚫 **No Superadmin signup** - Superadmin is in-built (hardcoded)
- ✅ **Admins are optional** - System can run with only Superadmin
- ✅ **Superadmin can do everything Admin does + more**
- ✅ All roles log in via the same login screen

---

## 🔐 Authentication & Approval Flow

### Signup UI Structure:
```
┌─────────────────────────────────┐
│  Sign up as Customer            │
│  Sign up as Vendor              │
├─────────────────────────────────┤
│  Sign up as Staff               │  ← Separate section below
└─────────────────────────────────┘

Login (all roles including Admin & Superadmin)
```

### Signup Fields:

**Customer:**
- Name, Email, Phone Number
- State, LGA
- **Estate OR Hotel** (choose one)
- **If Hotel:** Checkout date (required)

**Vendor:**
- Name, Email, Phone Number
- State, LGA (locked forever after signup)

**Staff:**
- Name, Email, Phone Number
- State, LGA

---

### Approval Workflow:

**Customer:**
- ✅ Immediate access after signup
- ✅ No approval needed
- ✅ Auto-assigned to Assignment Group based on estate/hotel selection

**Vendor & Staff:**
- ❌ Redirected immediately to **Pending Approval** screen
- ❌ Cannot access dashboards
- ❌ Cannot perform any actions
- ✅ Remain blocked until approved

### Approval Mechanism:
- **Who approves:** Admin (in their states) OR Superadmin (anywhere)
- **Approval source:** `profiles.approved = true`
- **Role source:** `user_roles` table
- **Rejection behavior:** Does NOT delete user (remains permanently blocked unless manually approved later)

### Role Upgrades:
- **Staff → Admin:** Only Superadmin can upgrade (assigns states to manage)
- **Admin → Superadmin:** Impossible (Superadmin is in-built only)

---

## 🏨 Hotel Account Lifecycle (CRITICAL)

### Hotel vs Estate:
- **Estate:** Permanent residential address
- **Hotel:** Temporary stay (requires checkout date)

### Hotel Checkout Flow:
```
1. Guest signs up as Customer
2. Selects "Hotel" (not Estate)
3. System asks: "Check-out date?"
4. Guest enters date (e.g., Jan 10, 2026)
5. Guest can order normally until checkout date
6. Package delivered to hotel security guard
7. Guest uses package code to collect from security
8. ON CHECKOUT DATE:
   - Account is SOFT DELETED (deactivated)
   - User cannot login
   - Order history preserved (for disputes/refunds)
   - Data not permanently deleted
```

**Rationale:** Prevents confusion and failed deliveries to checked-out guests.

---

## 📍 Location Hierarchy & Assignment Groups

### Structure:
**State → LGA → Assignment Group → (Staff + Vendors + Locations)**

### Admin/Superadmin Creates:
- LGAs (Local Government Areas)
- Estates
- Hotels
- **Assignment Groups** (the core innovation)

---

## 🎯 ASSIGNMENT GROUPS (CORE FEATURE)

### What is an Assignment Group?
A **micro-fulfillment zone** that connects:
- **1 Staff member** (exclusive - cannot be in multiple groups)
- **1-2 Vendors** (can be in multiple groups)
- **Multiple Estates/Hotels** (exclusive - each location in one group only)

### Example:
```
State: Lagos
  └── LGA: Ikeja
       ├── Group 1: "Ikeja Zone A"
       │    ├── Staff: Chidi (EXCLUSIVE)
       │    ├── Vendors: VendorA, VendorB (VendorA can also be in Group 2)
       │    └── Locations: Estate X, Estate Y
       │
       └── Group 2: "Ikeja Zone B"
            ├── Staff: Amina (EXCLUSIVE)
            ├── Vendors: VendorA, VendorC (VendorA serves both zones)
            └── Locations: Estate Z, Hotel W
```

### Rules:
1. ✅ **One Staff per group** (exclusive assignment)
2. ✅ **1-2 Vendors per group** (can be in multiple groups)
3. ✅ **Multiple Estates/Hotels per group** (exclusive per location)
4. ✅ **Admin can add estates/hotels to existing groups**
5. ✅ **Admin can assign vendor already in another group**
6. ❌ **Admin cannot assign staff already in another group**

### Customer Impact:
- Customer in **Estate X** only sees products from **VendorA & VendorB**
- Orders are delivered by **Chidi only**

### Staff Impact:
- **Chidi** only sees orders from **Estate X & Estate Y**
- **Chidi** only delivers within their assigned zone

### Vendor Impact:
- **VendorA** receives orders from **Estate X, Estate Y** (Group 1) AND **Estate Z, Hotel W** (Group 2)
- Receives **separate payments** from Chidi (Group 1 orders) and Amina (Group 2 orders)

### What if LGA has no groups?
- Customer signup shows: **"No vendors available in your area yet"**
- Customer cannot complete signup until Admin/Superadmin creates a group

---

## 🚚 Delivery & Batching System

### Fixed Delivery Batches:
- **10:00 AM**
- **1:00 PM** (13:00)
- **4:00 PM** (16:00)

### How Batching Works with Assignment Groups:
```
10:00 AM Batch (LGA-wide, filtered by groups)

Staff Chidi receives:
  - All orders from Estate X & Estate Y customers (Group 1)

Staff Amina receives:
  - All orders from Estate Z & Hotel W customers (Group 2)
```

**Batches are global to the LGA, but filtered by assignment group.**

### Order Assignment:
- Orders are assigned to the **next available batch**
- **One order = one batch** (immutable)
- Batch assignment is automatic, not manual

### Serial Code Format:
**`EST-BLK-A-023`**

Where:
- `EST` = Estate/Hotel code
- `BLK` = Block/grouping
- `A/B/C` = Batch slot (A=10AM, B=1PM, C=4PM)
- `023` = Sequence number

---

## 💰 PAYMENT FLOW (FULLY ONLINE - PAYSTACK)

### The Complete Journey:

**1. Customer Checkout:**
```
Order Total: ₦5,000 (goods)
Delivery Fee: ₦400 (per LGA, editable by Admin/Superadmin)
───────────────
CUSTOMER PAYS: ₦5,400 via Paystack
```

**2. Money Status:**
- ₦5,400 held by platform (Paystack)
- Vendor does NOT receive money yet
- Order status: `pending`

**3. Staff Delivers Order:**
- Staff marks order: `out_for_delivery`
- Staff completes delivery
- Staff clicks: **"Complete & Pay Vendor"**

**4. System Auto-Calculates Vendor Payout:**
```
┌─────────────────────────────────┐
│ Pay Vendor: VendorA             │
├─────────────────────────────────┤
│ Order Total: ₦5,000             │
│ (Delivery fee ₦400 excluded)    │
│                                 │
│ AMOUNT LOCKED: ₦5,000           │
│ (Cannot be edited by Staff)     │
├─────────────────────────────────┤
│ Vendor Bank Details:            │
│ Bank: GTBank                    │
│ Account: 0123456789             │
│ Name: VendorA Enterprises       │
├─────────��───────────────────────┤
│ [Confirm Payment] ✅            │
└─────────────────────────────────┘
```

**5. Instant Transfer:**
- System transfers ₦5,000 to VendorA via Paystack
- ₦400 remains in platform account
- **Receipt generated** for Staff and Vendor (Paystack receipt)
- Order status: `delivered`

**6. Platform Revenue:**
- Platform earns ₦400 per delivery (not commission on goods)
- Delivery fee can be edited per LGA by Admin/Superadmin

---

### Out-of-Stock Refund Flow:

**Scenario:** Customer already paid ₦5,400, but item unavailable

```
1. Staff marks item: "Unavailable"
2. System automatically refunds ₦5,400 to customer (via Paystack)
3. Customer receives notification: "Refund processed"
4. Order status: cancelled
5. No vendor payout occurs
```

---

### Multi-Group Vendor Payments:

**Scenario:** VendorA is in Group 1 (Staff Chidi) and Group 2 (Staff Amina)

```
10:00 AM Batch:

Staff Chidi (Group 1):
  - Customer from Estate X orders ₦3,000 from VendorA
  - Chidi pays VendorA: ₦3,000

Staff Amina (Group 2):
  - Customer from Estate Z orders ₦2,000 from VendorA
  - Amina pays VendorA: ₦2,000

Result: VendorA receives TWO separate payments (₦3,000 + ₦2,000)
```

**This is intentional** - each Staff handles their zone independently.

---

## 🔄 Order Status Flow

**`pending → out_for_delivery → delivered`**

**OR**

**`pending → cancelled`** (if item unavailable)

### Who Updates What:
- **Customer:** Read-only (can only view status)
- **Staff:** Updates status + marks items unavailable + triggers vendor payout
- **Admin/Superadmin:** Sees everything (full visibility)

---

## 💳 Delivery Fee Management

### Per-LGA Pricing:
```
Lagos (Ikeja LGA): ₦400
Lagos (Surulere LGA): ₦450
Abuja (Garki LGA): ₦500
```

### Who Can Edit:
- Admin: Delivery fees in their assigned states only
- Superadmin: Delivery fees anywhere

### Default:
- ₦400 for all LGAs (can be changed)

---

## 🛒 Product & Vendor Logic

### Product Assignment:
- Vendors add products after approval
- Products are visible to **customers in the vendor's assigned group(s) only**
- Same product can be sold by **multiple vendors**

### Vendor Account Details:
After approval, Vendor can edit profile to add:
- Bank name
- Account number
- Account name

**Who can view these details:**
- Staff (for manual verification before payment)
- Admin (for management)
- Superadmin (for management)

**Customers CANNOT see vendor bank details.**

---

## 👤 ROLE PERMISSIONS (FINAL)

### **Superadmin (In-built, Login Only)**

**Can do EVERYTHING Admin does + more:**
- ✅ Upgrade Staff → Admin (assign states to manage)
- ✅ Approve/Disapprove anyone anywhere (no geographical limits)
- ✅ Create LGAs, Estates, Hotels anywhere
- ✅ Create Assignment Groups anywhere
- ✅ Edit delivery fees anywhere
- ✅ View all vendor account details
- ✅ Oversee all orders, all states
- ✅ Promote/demote Admins
- ✅ System-wide analytics

**Cannot:**
- ❌ Place orders as Customer
- ❌ Add products as Vendor
- ❌ Deliver orders as Staff

---

### **Admin (Upgraded from Staff, Login Only)**

**Geographical scope:** Assigned states only (set by Superadmin)

**Can do:**
- ✅ Approve Staff & Vendors **in assigned states**
- ✅ Create LGAs **in assigned states**
- ✅ Create Estates/Hotels **in assigned states**
- ✅ Create Assignment Groups **in assigned states**
- ✅ Add estates/hotels to existing groups
- ✅ Assign vendors already in another group
- ✅ Edit delivery fees **in assigned states**
- ✅ View vendor account details **in assigned states**
- ✅ Oversee orders **in assigned states**
- ✅ View staff locations **in assigned states**
- ✅ Receive customer care escalations

**Cannot:**
- ❌ Assign staff already in another group
- ❌ Upgrade Staff to Admin (only Superadmin)
- ❌ Manage other states
- ❌ Place orders as Customer
- ❌ Override batch assignments

---

### **Staff (Public Signup, Requires Approval)**

**Signup fields:** Name, Email, Phone, **State, LGA**

**After approval:**
- ✅ Assigned to **ONE group** by Admin/Superadmin (exclusive)
- ✅ View orders from assigned estates/hotels only
- ✅ Deliver to assigned zone only
- ✅ Update order status (`out_for_delivery`, `delivered`)
- ✅ Mark items unavailable (triggers auto-refund)
- ✅ Trigger vendor payout after delivery
- ✅ View vendor bank details (for payment verification)
- ✅ Respond to customer care messages
- ✅ View assigned batch schedule

**Cannot:**
- ❌ See orders outside their group
- ❌ Edit delivery fees
- ❌ Approve other users
- ❌ Create products
- ❌ Be in multiple groups

---

### **Vendor (Public Signup, Requires Approval)**

**Signup fields:** Name, Email, Phone, State, LGA

**After approval:**
- ✅ Edit profile to add **bank account details**
- ✅ Add/Edit products
- ✅ Products visible to customers in assigned group(s)
- ✅ View orders from assigned customers only
- ✅ Receive instant payouts after delivery
- ✅ Can be assigned to **multiple groups** (serve multiple zones)
- ✅ Receive separate payments from each Staff
- ✅ View batch times for orders

**Cannot:**
- ❌ Change LGA after signup (locked forever)
- ❌ See other vendors' products
- ❌ Update order status
- ❌ See customer addresses (privacy)

---

### **Customer (Public Signup, No Approval)**

**Signup fields:** Name, Email, Phone, State, LGA, **Estate OR Hotel**

**If Hotel selected:** Must provide checkout date

**After signup:**
- ✅ Auto-assigned to Assignment Group based on location
- ✅ See products from assigned vendors only
- ✅ Browse by categories
- ✅ Add to cart
- ✅ Checkout (pay via Paystack)
- ✅ Track order status (read-only)
- ✅ Chat with assigned Staff (customer care)
- ✅ View order history
- ✅ Receive refunds automatically if item unavailable

**Hotel customers:**
- ✅ Account auto-deactivates on checkout date (soft delete)
- ✅ Can no longer login after checkout
- ✅ Order history preserved

**Cannot:**
- ❌ See vendors outside their group
- ❌ Choose delivery time (batch is auto-assigned)
- ❌ Contact vendors directly

---

## 💬 CUSTOMER CARE CHAT SYSTEM

### Structure:
- Customer sees **"Chat with Support"** in dashboard
- Opens chat panel
- Messages sent to **assigned Staff member**
- Staff sees all customer chats in their dashboard
- **Message-based** (refresh to see new messages, not real-time)

### Features:
- Text-only (no file uploads for now)
- Customer can send complaints, questions
- Staff responds directly
- Chat history preserved

### Notifications:
- Customer: "New message from support"
- Staff: "New message from [Customer Name]"

---

## 🔔 NOTIFICATIONS (COMPREHENSIVE)

### **Customer:**
- ✅ Order confirmed
- ✅ Payment successful (₦X charged)
- ✅ Order assigned to [Batch Time]
- ✅ Out for delivery (Staff on the way)
- ✅ Delivered successfully
- ✅ Item unavailable - full refund processed
- ✅ New message from Staff (chat)
- ✅ Account will expire on [Checkout Date] (hotel customers)

### **Vendor:**
- ✅ New order received (Order #, Customer, Items)
- ✅ Payment received (₦X from Staff [Name])
- ✅ Product low stock warning (auto-detect if qty < 5)
- ✅ Item marked unavailable by Staff
- ✅ Approved by Admin

### **Staff:**
- ✅ New batch assigned ([Batch Time], X orders)
- ✅ Delivery reminder (1 hour before batch time)
- ✅ New customer message (chat notification)
- ✅ Approved by Admin
- ✅ Assigned to Group [Name]

### **Admin:**
- ✅ New Staff approval request (in assigned states)
- ✅ New Vendor approval request (in assigned states)
- ✅ Staff marked item unavailable (refund triggered)
- ✅ Refund processed notification
- ✅ Daily order summary (assigned states)
- ✅ New Assignment Group created

### **Superadmin:**
- ✅ New Admin upgrade request
- ✅ All Admin notifications + system-wide view
- ✅ Payment gateway issues (Paystack errors)
- ✅ System alerts (critical errors)

---

## 🎨 UX Philosophy (NON-NEGOTIABLE)

### Core Principles:
- **Calm** - No urgency pressure
- **Predictable** - Clear expectations
- **Soft feedback** - Gentle confirmations
- **Clear states** - Always know where you are

### What We DO NOT Do:
- ❌ No "Only 2 left!" badges
- ❌ No countdown timers
- ❌ No aggressive notifications
- ❌ No fake scarcity tactics

### What We DO:
- ✅ Soft color palette (pastels, muted tones)
- ✅ Clear loading states (skeleton screens, gentle spinners)
- ✅ Informative, not alarming messages
- ✅ Breathing room in layouts
- ✅ Calm confirmation messages: "Order placed successfully. We'll prepare it for [Batch Time]."

---

## 🗂️ DATABASE SCHEMA (IMPLIED)

### Core Tables:

**Authentication:**
- `users` - Supabase Auth (email, password)
- `profiles` - User data + `approved` boolean + `is_active` (for hotel soft delete)
- `user_roles` - Role assignments (customer, vendor, staff, admin, superadmin)

**Geography:**
- `states` - Nigerian states
- `lgas` - Local Government Areas
- `estates` - Residential estates
- `hotels` - Hotel locations

**Assignment Groups (NEW):**
- `assignment_groups` - Group metadata (name, LGA, created_by)
- `group_staff` - One-to-one (group_id, staff_id UNIQUE)
- `group_vendors` - One-to-many (group_id, vendor_id)
- `group_locations` - One-to-many (group_id, location_id, location_type)

**Products:**
- `products` - Product catalog (vendor_id, name, price, stock)
- `product_images` - Product photos

**Orders:**
- `orders` - Customer orders (customer_id, status, batch_time, serial_code)
- `order_items` - Items within orders
- `batches` - Delivery batch schedule

**Payments:**
- `transactions` - Payment records (Paystack refs)
- `vendor_accounts` - Bank details (bank_name, account_number, account_name)
- `delivery_fees` - Per-LGA fees (lga_id UNIQUE, fee, updated_by)

**Customer Care:**
- `chat_messages` - Customer-Staff messages (customer_id, staff_id, message, timestamp)

**Hotel Lifecycle:**
- `hotel_accounts` - customer_id, hotel_id, room_number, checkout_date, is_active

---

## 🔒 Security & Data Rules

### Role Source of Truth:
- **`user_roles` table** is the role source
- **`profiles.approved`** is the approval source
- **`profiles.is_active`** for hotel account deactivation
- UI **cannot bypass** approval logic

### Access Control:
- Staff **cannot see** Admin/Superadmin data
- Admin **cannot act as** Customer
- Vendor **cannot see** other vendors' products (edit view)
- Customer **cannot see** backend operations
- Customer **cannot see** vendor bank details

### Payment Security:
- Vendor payout amount is **system-calculated, uneditable by Staff**
- Paystack handles all transactions (PCI compliant)
- Refunds are automatic (no manual intervention)

---

## 🚧 Delicate Implementation Parts (DO NOT TOUCH CASUALLY)

These are **high-risk areas** that require careful handling:

1. **Assignment Group Logic**
   - Staff can only be in ONE group (enforce at DB level)
   - Vendors can be in MULTIPLE groups
   - Estates/Hotels can only be in ONE group

2. **Hotel Account Expiry**
   - Cron job checks `checkout_date` daily
   - Sets `is_active = false` on expired accounts
   - Prevents login but preserves data

3. **Vendor Payout Calculation**
   - Must exclude delivery fee from vendor payout
   - Amount must be locked (uneditable by Staff)
   - Receipt must be generated via Paystack

4. **Batch Assignment with Groups**
   - Global batch time, filtered by group
   - Staff only sees their group's orders

5. **Refund Automation**
   - Must trigger immediately when item marked unavailable
   - Full refund (goods + delivery fee)
   - Notification to customer

---

## ✅ What We've Decided (Immutable)

1. ✅ **Superadmin is core** - System can run without Admins
2. ✅ **Assignment Groups** - Micro-fulfillment zones
3. ✅ **Hotel accounts expire** - Soft delete after checkout
4. ✅ **Vendors can serve multiple groups** - Staff cannot
5. ✅ **Separate payments per Staff** - Vendor receives multiple transfers
6. ✅ **Per-LGA delivery fees** - Not global
7. ✅ **Customer care is message-based** - Not real-time
8. ✅ **Paystack only** - No cash payments
9. ✅ **Auto-refunds** - No manual admin approval

---

## 🔜 Implementation Phases

1. **Phase 1:** Auth + Role selection + Pending approval + Superadmin setup
2. **Phase 2:** Admin dashboard (create LGAs, Estates, Assignment Groups)
3. **Phase 3:** Vendor flow (add products, bank details)
4. **Phase 4:** Customer flow (browse by group, cart, checkout, Paystack)
5. **Phase 5:** Staff flow (view batch, deliver, pay vendor, mark unavailable)
6. **Phase 6:** Notifications + Customer care chat
7. **Phase 7:** Hotel account expiry automation
8. **Phase 8:** Polish (calm UX, loading states, microcopy)

---

**END OF PRD**
