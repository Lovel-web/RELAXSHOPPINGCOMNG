import React, {
  createContext,
  useContext,
  useState,
  useEffect,
} from "react";
import { supabase } from "../utils/supabase/client";
import {
  projectId,
  publicAnonKey,
} from "../../utils/supabase/info";

type UserRole = "customer" | "vendor" | "staff" | "admin";

interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  approved: boolean;
}

interface AuthContextType {
  user: User | null;
  accessToken: string | null;
  loading: boolean;
  signUp: (
    email: string,
    password: string,
    name: string,
    role: UserRole,
  ) => Promise<{ error?: string; message?: string }>;
  signIn: (
    email: string,
    password: string,
  ) => Promise<{ error?: string }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(
  undefined,
);

export function AuthProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(
    null,
  );
  const [loading, setLoading] = useState(true);

  const serverUrl = `https://${projectId}.supabase.co/functions/v1/make-server-5fb75e13`;

  // Fetch user profile from server
  const fetchUserProfile = async (token: string) => {
    try {
      const response = await fetch(`${serverUrl}/profile`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        console.error(
          `Failed to fetch profile: ${response.statusText}`,
        );
        return null;
      }

      const data = await response.json();
      return data.user;
    } catch (error) {
      console.error("Error fetching user profile:", error);
      return null;
    }
  };

  // Check for existing session on mount
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession();

        if (session?.access_token) {
          setAccessToken(session.access_token);
          const userProfile = await fetchUserProfile(
            session.access_token,
          );
          setUser(userProfile);
        }
      } catch (error) {
        console.error("Error initializing auth:", error);
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();

    // Listen for auth state changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (session?.access_token) {
          setAccessToken(session.access_token);
          const userProfile = await fetchUserProfile(
            session.access_token,
          );
          setUser(userProfile);
        } else {
          setAccessToken(null);
          setUser(null);
        }
      },
    );

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const signUp = async (
    email: string,
    password: string,
    name: string,
    role: UserRole,
  ) => {
    try {
      const response = await fetch(`${serverUrl}/signup`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password, name, role }),
      });

      const data = await response.json();

      if (!response.ok) {
        return { error: data.error || "Signup failed" };
      }

      // After successful signup, sign in the user
      const signInResult = await signIn(email, password);

      if (signInResult.error) {
        return { error: signInResult.error };
      }

      return { message: data.message };
    } catch (error) {
      console.error("Signup error:", error);
      return { error: "Network error during signup" };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } =
        await supabase.auth.signInWithPassword({
          email,
          password,
        });

      if (error) {
        console.error("Sign in error:", error.message);
        return { error: error.message };
      }

      if (data.session?.access_token) {
        setAccessToken(data.session.access_token);
        const userProfile = await fetchUserProfile(
          data.session.access_token,
        );
        setUser(userProfile);
      }

      return {};
    } catch (error) {
      console.error("Sign in error:", error);
      return { error: "Network error during sign in" };
    }
  };

  const signOut = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      setAccessToken(null);
    } catch (error) {
      console.error("Sign out error:", error);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        accessToken,
        loading,
        signUp,
        signIn,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error(
      "useAuth must be used within an AuthProvider",
    );
  }
  return context;
}