import { useAuth } from '../../contexts/AuthContext';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Clock } from 'lucide-react';

export default function PendingApproval() {
  const { user, signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut();
  };

  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-slate-50">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-amber-100">
            <Clock className="h-8 w-8 text-amber-600" />
          </div>
          <CardTitle className="text-2xl">Approval Pending</CardTitle>
          <CardDescription>
            Your {user?.role} account is awaiting admin approval
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="rounded-lg bg-slate-50 p-4 space-y-2">
            <p className="text-sm text-slate-700">
              <span className="font-medium">Name:</span> {user?.name}
            </p>
            <p className="text-sm text-slate-700">
              <span className="font-medium">Email:</span> {user?.email}
            </p>
            <p className="text-sm text-slate-700">
              <span className="font-medium">Role:</span>{' '}
              <span className="capitalize">{user?.role}</span>
            </p>
          </div>

          <div className="space-y-2 text-sm text-slate-600">
            <p>
              Thank you for registering with RelaxShopping. Your account is currently under review.
            </p>
            <p>
              An administrator will review your application and approve your account shortly. 
              You'll be able to access your dashboard once approved.
            </p>
            <p className="text-xs text-slate-500">
              Please check back later or contact support if you have questions.
            </p>
          </div>

          <Button variant="outline" onClick={handleSignOut} className="w-full mt-6">
            Sign Out
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
